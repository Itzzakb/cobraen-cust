import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  standalone: true,
  selector: 'app-signup',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss'],
  imports: [CommonModule, ReactiveFormsModule, RouterModule, FormsModule, ]
})
export class SignupComponent {
  signupForm: FormGroup;

  constructor(private fb: FormBuilder, private toastr: ToastrService) {
    this.signupForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]]
    });
  }

  onSubmit() {
    if (this.signupForm.valid) {
      console.log(this.signupForm.value);
      this.toastr.success('Signup successful!', 'Success');
      this.signupForm.reset();
    } else {
      this.toastr.error('Please fill out all fields correctly.', 'Form Invalid');
      this.signupForm.markAllAsTouched();
    }
  }
}
