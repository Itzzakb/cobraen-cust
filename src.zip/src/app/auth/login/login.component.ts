import { CommonModule } from '@angular/common';
import { Component, ElementRef, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, RouterLink, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  step: 'mobile' | 'otp' | 'verified' = 'mobile';

  otp: string[] = ['', '', '', ''];

  @ViewChild('otp1') otp1!: ElementRef<HTMLInputElement>;
  @ViewChild('otp2') otp2!: ElementRef<HTMLInputElement>;
  @ViewChild('otp3') otp3!: ElementRef<HTMLInputElement>;
  @ViewChild('otp4') otp4!: ElementRef<HTMLInputElement>;
  form: FormGroup;

  constructor(private fb: FormBuilder, private toastr: ToastrService) {
    this.form = this.fb.group({
      mobile: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
    });
  }

  sendOtp() {
    if (this.form.invalid) {
      this.toastr.error('Enter valid mobile number');
      return;
    }
    this.toastr.success('OTP sent successfully');
    this.step = 'otp';
  }

  onInput(event: Event, index: number) {
    const input = event.target as HTMLInputElement;
    const value = input.value.replace(/\D/g, ''); // Only digits

    this.otp[index] = value;

    if (value && index < 3) {
      this.focusInput(index + 1);
    }

    this.checkOtpComplete();
  }

  onKeyDown(event: KeyboardEvent, index: number) {
    const input = event.target as HTMLInputElement;
    if (event.key === 'Backspace') {
      this.otp[index] = '';
      if (!input.value && index > 0) {
        this.focusInput(index - 1);
      }
    }
  }

  focusInput(index: number) {
    const refs = [this.otp1, this.otp2, this.otp3, this.otp4];
    refs[index]?.nativeElement.focus();
  }

  checkOtpComplete() {
    if (this.otp.every((d) => d !== '')) {
      const fullOtp = this.otp.join('');
      console.log('Full OTP:', fullOtp);
      // TODO: Submit OTP or show success
    }
  }
  verifyOtp() {
    if (this.otp.length === 4) {
      this.toastr.success('OTP verified');
      this.step = 'verified';
    } else {
      this.toastr.error('Invalid OTP');
    }
  }

  backToMobile() {
    this.step = 'mobile';
  }
}
