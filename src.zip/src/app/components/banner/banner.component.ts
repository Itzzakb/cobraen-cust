import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-banner',
  imports: [CommonModule],
  templateUrl: './banner.component.html',
  styleUrl: './banner.component.scss'
})
export class BannerComponent implements OnChanges {
  @Input() path: string = '';


ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      this.path = changes['path'].currentValue;
      console.log(this.path)
    }

  }

}
