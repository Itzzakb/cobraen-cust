import { CommonModule } from '@angular/common';
import { Component, ElementRef, Input, OnChanges, OnInit, QueryList, SimpleChanges, ViewChild, ViewChildren } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CarouselModule, OwlOptions, CarouselComponent, CarouselSlideDirective } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-full-outfit',
  imports: [CarouselModule,CommonModule, RouterLink,],
  templateUrl: './full-outfit.component.html',
  styleUrl: './full-outfit.component.scss',
})
export class FullOutfitComponent implements OnChanges{
  
    @Input() path: string = '';


ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      if(changes['path'].currentValue === 'women'){

      }
      
    }

  }

  get currentModels(): any[] {
  return this.path === 'women' ? this.womenModels : this.models;
}

  options = ['Summer', 'Fall', 'Winter', 'Spring'];
  selected = 'Summer';
  dropdownOpen = false;

  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  selectOption(option: string, event: Event) {
    event.stopPropagation(); // prevents blur event from immediately closing
    this.selected = option;
    this.dropdownOpen = false;
  }

  closeDropdown() {
    this.dropdownOpen = false;
  }
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  }

    fulloutfitSlider: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 300,
    navText: ['<i class="bi bi-chevron-left"></i>', '<i class="bi bi-chevron-right"></i>'],
    responsive: {
      0: {
        items: 1,
      },
      400: {
        items: 2,
      },
      740: {
        items: 3,
      },
      940: {
        items: 3,
      }
    },
    nav: true
  }

  models = [
    {
      id: 'model1',
      image: '/images/men-categories/jacket.svg',
      shirtId: 'shirt1',
      pantId: 'pant1',
      products: [
        {
          id: 'shirt1',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant1',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model2',
      image: '/images/men-categories/shirt.svg',
      shirtId: 'shirt2',
      pantId: 'pant2',
      products: [
        {
          id: 'shirt2',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant2',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model3',
      image: '/images/men-categories/t-shirt.svg',
      shirtId: 'shirt3',
      pantId: 'pant3',
      products: [
        {
          id: 'shirt3',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant3',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model4',
      image: '/images/men-categories/pant.svg',
      shirtId: 'shirt4',
      pantId: 'pant4',
      products: [
        {
          id: 'shirt4',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant4',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    }
  ];
  womenModels = [
    {
      id: 'model1',
      image: '/images/women-categories/women2.png',
      shirtId: 'shirt1',
      pantId: 'pant1',
      products: [
        {
          id: 'shirt1',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women3.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant1',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women4.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model2',
      image: '/images/women-categories/women1.png',
      shirtId: 'shirt2',
      pantId: 'pant2',
      products: [
        {
          id: 'shirt2',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women4.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant2',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women3.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model3',
      image: '/images/women-categories/women2.png',
      shirtId: 'shirt3',
      pantId: 'pant3',
      products: [
        {
          id: 'shirt3',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women1.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant3',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women4.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model4',
      image: '/images/women-categories/women3.png',
      shirtId: 'shirt4',
      pantId: 'pant4',
      products: [
        {
          id: 'shirt4',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women2.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant4',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women1.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    }
  ];

  @ViewChildren('productCard') productCards!: QueryList<ElementRef>;

  scrollToProduct(productId: string) {
    const target = this.productCards.find(
      (el) => el.nativeElement.id === productId
    );
    if (target) {
      target.nativeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }


  filters: string[] = ['Edgy', 'Chill', 'Beachy', 'Sporty', 'Retro'];
  trackbyModelId(index: number, model: any): string {
    return model.id;

  }
}
