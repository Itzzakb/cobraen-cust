import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FullOutfitComponent } from './full-outfit.component';

describe('FullOutfitComponent', () => {
  let component: FullOutfitComponent;
  let fixture: ComponentFixture<FullOutfitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FullOutfitComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FullOutfitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
