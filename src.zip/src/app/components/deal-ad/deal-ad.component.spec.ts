import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DealAdComponent } from './deal-ad.component';

describe('DealAdComponent', () => {
  let component: DealAdComponent;
  let fixture: ComponentFixture<DealAdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DealAdComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DealAdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
