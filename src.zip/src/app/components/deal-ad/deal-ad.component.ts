import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-deal-ad',
  imports: [CommonModule],
  templateUrl: './deal-ad.component.html',
  styleUrl: './deal-ad.component.scss'
})
export class DealAdComponent implements OnInit, OnDestroy, OnChanges {
  @Input() path: string = '';

  ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      this.path = changes['path'].currentValue;
      console.log(this.path)
    }

  }
  
 targetDate = new Date(new Date().getTime() + 12 * 60 * 60 * 1000); // 12 hours from now
  timerDisplay = [
    { label: 'Days', value: '00' },
    { label: 'Hours', value: '00' },
    { label: 'Minutes', value: '00' },
    { label: 'Seconds', value: '00' },
  ];

  private intervalId: any;

  ngOnInit() {
    this.updateTimer();
    this.intervalId = setInterval(() => this.updateTimer(), 1000);
  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
  }

  updateTimer() {
    const now = new Date().getTime();
    const distance = this.targetDate.getTime() - now;

    if (distance <= 0) {
      this.timerDisplay = [
        { label: 'Days', value: '00' },
        { label: 'Hours', value: '00' },
        { label: 'Minutes', value: '00' },
        { label: 'Seconds', value: '00' },
      ];
      clearInterval(this.intervalId);
      return;
    }

    const days = this.padZero(Math.floor(distance / (1000 * 60 * 60 * 24)));
    const hours = this.padZero(Math.floor((distance / (1000 * 60 * 60)) % 24));
    const minutes = this.padZero(Math.floor((distance / (1000 * 60)) % 60));
    const seconds = this.padZero(Math.floor((distance / 1000) % 60));

    this.timerDisplay = [
      { label: 'Days', value: days },
      { label: 'Hours', value: hours },
      { label: 'Minutes', value: minutes },
      { label: 'Seconds', value: seconds },
    ];
  }

  padZero(num: number): string {
    return num < 10 ? '0' + num : num.toString();
  }
}
