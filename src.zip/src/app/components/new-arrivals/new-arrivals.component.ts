import { CommonModule } from '@angular/common';
import { Component, Input, SimpleChanges } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from "../../shared/header/header.component";
import { FooterComponent } from '../../shared/footer/footer.component';

@Component({
  selector: 'app-new-arrivals',
  imports: [CommonModule, RouterLink, HeaderComponent, FooterComponent],
  templateUrl: './new-arrivals.component.html',
  styleUrl: './new-arrivals.component.scss',
})
export class NewArrivalsComponent {

  @Input() path: string = '';


ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      if(changes['path'].currentValue === 'women'){

      }
      
    }

  }

  get currentArrivals(): any[] {
  return this.path === 'women' ? this.WoemnNewArrivals : this.newArrivals;
}
  newArrivals = [
    {
      id: 1,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/t-shirt.svg',
      price: '1,999',
      discountPrice: '1,599',
      discount: 20,
    },
    {
      id: 2,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/shirt.svg',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
    {
      id: 3,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/pant.svg',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
    {
      id: 4,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/jacket.svg',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
  ];
  WoemnNewArrivals = [
    {
      id: 1,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women1.png',
      price: '1,999',
      discountPrice: '1,599',
      discount: 20,
    },
    {
      id: 2,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women2.png',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
    {
      id: 3,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women3.png',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
    {
      id: 4,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women4.png',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
  ];
}
