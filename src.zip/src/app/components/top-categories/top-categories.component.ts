import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CarouselModule, OwlOptions, CarouselSlideDirective } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-top-categories',
  imports: [CarouselModule, CommonModule, RouterLink],
  templateUrl: './top-categories.component.html',
  styleUrl: './top-categories.component.scss'
})
export class TopCategoriesComponent  implements OnChanges{
  @Input() path: string = '';


ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      if(changes['path'].currentValue === 'women'){

      }
      
    }

  }

  get currentCategories(): any[] {
  return this.path === 'women' ? this.womenCategories : this.categories;
}

  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    navSpeed: 300,
    navText: ['<i class="bi bi-chevron-left"></i>', '<i class="bi bi-chevron-right"></i>'],
    responsive: {
      0: {
        items: 1,
        slideBy: 1,
        nav: false,
        dots: true
      },
      400: {
        items: 2,
        slideBy: 2,
        nav: false,
        dots: true
      },
      740: {
        items: 3,
        slideBy: 3,
        nav: true,
        dots: false
      },
      940: {
        items: 5,
        slideBy: 5,
        nav: false,
        dots: true
      }
    },
  }

  categories = [
    {
      id: 1,
      name: 'T-shirts',
      image: '/images/men-categories/t-shirt.svg',
    },
    {
      id: 2,
      name: 'Shirts',
      image: '/images/men-categories/shirt.svg',
    },
    {
      id: 3,
      name: 'Pant',
      image: '/images/men-categories/pant.svg',
    },
    {
      id: 4,
      name: 'Jacket',
      image: '/images/men-categories/jacket.svg',
    },
    {
      id: 5,
      name: 'Shorts',
      image: '/images/men-categories/shorts.svg',
    },
    {
      id: 6,
      name: 'T-shirts',
      image: '/images/men-categories/t-shirt.svg',
    },
    {
      id: 7,
      name: 'Shirts',
      image: '/images/men-categories/shirt.svg',
    },
    {
      id: 8,
      name: 'Pant',
      image: '/images/men-categories/pant.svg',
    },
    {
      id: 9,
      name: 'Jacket',
      image: '/images/men-categories/jacket.svg',
    },
    {
      id: 10,
      name: 'Shorts',
      image: '/images/men-categories/shorts.svg',
    },
    {
      id: 11,
      name: 'T-shirts',
      image: '/images/men-categories/t-shirt.svg',
    },
    {
      id: 12,
      name: 'Shirts',
      image: '/images/men-categories/shirt.svg',
    },
    {
      id: 13,
      name: 'Pant',
      image: '/images/men-categories/pant.svg',
    },
    
  ]

  womenCategories = [
    {
      id: 1,
      name: 'T-shirts',
      image: '/images/women-categories/women1.png',
    },
    {
      id: 2,
      name: 'Shirts',
      image: '/images/women-categories/women2.png',
    },
    {
      id: 3,
      name: 'Pant',
      image: '/images/women-categories/women3.png',
    },
    {
      id: 4,
      name: 'Jacket',
      image: '/images/women-categories/women4.png',
    },
    {
      id: 5,
      name: 'Shorts',
      image: '/images/women-categories/women1.png',
    },
    {
      id: 6,
      name: 'T-shirts',
      image: '/images/women-categories/women2.png',
    },
    {
      id: 7,
      name: 'Shirts',
      image: '/images/women-categories/women3.png',
    },
    {
      id: 8,
      name: 'Pant',
      image: '/images/women-categories/women4.png',
    },
    {
      id: 9,
      name: 'Jacket',
      image: '/images/women-categories/women1.png',
    },
    {
      id: 10,
      name: 'Shorts',
      image: '/images/women-categories/women2.png',
    },
    
    
  ]
}
