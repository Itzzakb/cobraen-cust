import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CarouselModule, OwlOptions, SlidesOutputData } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-one-piece',
  imports: [CommonModule, RouterLink, CarouselModule],
  templateUrl: './one-piece.component.html',
  styleUrl: './one-piece.component.scss',
  encapsulation: ViewEncapsulation.Emulated
})
export class OnePieceComponent implements OnChanges{
  @Input() path: string = '';


ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      if(changes['path'].currentValue === 'women'){

      }
      
    }

  }

  get currentModels(): any[] {
  return this.path === 'women' ? this.womenModels : this.models;
}
  activeIndex: number = 0;
  models = [
    {
      id: 'model1',
      image: '/images/men-categories/jacket.svg',
      shirtId: 'shirt1',
      pantId: 'pant1',
      products: [
        {
          id: 'shirt1',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant1',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant1',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model2',
      image: '/images/men-categories/shirt.svg',
      shirtId: 'shirt2',
      pantId: 'pant2',
      products: [
        {
          id: 'shirt2',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/jacket.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant2',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shorts.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant2',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shorts.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model3',
      image: '/images/men-categories/t-shirt.svg',
      shirtId: 'shirt3',
      pantId: 'pant3',
      products: [
        {
          id: 'shirt3',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant3',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant3',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model4',
      image: '/images/men-categories/pant.svg',
      shirtId: 'shirt4',
      pantId: 'pant4',
      products: [
        {
          id: 'shirt4',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/t-shirt.svg',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant4',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant4',
          name: 'Lavender AOP Comfort Shirt',
          image: '/images/men-categories/shirt.svg',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    }
  ];
  womenModels = [
    {
      id: 'model1',
      image: '/images/women-categories/women2.png',
      shirtId: 'shirt1',
      pantId: 'pant1',
      products: [
        {
          id: 'shirt1',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women1.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant1',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women2.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant1',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women3.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model2',
      image: '/images/women-categories/women1.png',
      shirtId: 'shirt2',
      pantId: 'pant2',
      products: [
        {
          id: 'shirt2',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women2.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant2',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women3.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant2',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women4.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    {
      id: 'model3',
      image: '/images/women-categories/women4.png',
      shirtId: 'shirt3',
      pantId: 'pant3',
      products: [
        {
          id: 'shirt3',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women3.png',
          price: '1,999',
          discountPrice: '1,599',
          discount: 20,
        },
        {
          id: 'pant3',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women2.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
        {
          id: 'pant3',
          name: 'Lavender AOP Comfort Shirt',
      image: '/images/women-categories/women1.png',
          price: 499,
          discountPrice: 399,
          discount: 20,
        },
      ],
    },
    
  ];

      onePieceSlider: OwlOptions = {
    loop: true,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 300,
    navText: ['<i class="bi bi-arrow-left"></i>', '<i class="bi bi-arrow-right"></i>'],
    items: 1,
    nav: true,
    // center: true
  }

onTranslated(event: SlidesOutputData) {
    if (event.startPosition !== undefined) {
      this.activeIndex =  event.startPosition;
      console.log('Active index on translated:', this.models[this.activeIndex].products);
      // You can do whatever you need with the active index here
    }
  }  
}
