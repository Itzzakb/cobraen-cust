import { Component, HostListener } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CartDrawerComponent } from './shared/cart-drawer/cart-drawer.component';
import { WishlistDrawerComponent } from './shared/wishlist-drawer/wishlist-drawer.component';
import { CategoriesDrawerComponent } from './shared/categories-drawer/categories-drawer.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, CartDrawerComponent, WishlistDrawerComponent, CategoriesDrawerComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'COBRAEN';
  showScrollTop = false;

  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.showScrollTop = window.scrollY > 200;
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
