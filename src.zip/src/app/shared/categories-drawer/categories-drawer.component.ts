import { Component, signal, Input, Output, EventEmitter, computed, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignalService } from '../../services/signal.service';

@Component({
  selector: 'app-categories-drawer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './categories-drawer.component.html',
  styleUrls: ['./categories-drawer.component.scss']
})
export class CategoriesDrawerComponent {
  signalService = inject(SignalService);
  isOpen = this.signalService.isOpen;


  categories = [
    { name: 'Men', icon: 'bi-person' },
    { name: 'Women', icon: 'bi-gender-female' },
    { name: 'Kids', icon: 'bi-emoji-smile' },
    { name: 'Accessories', icon: 'bi-bag' },
    { name: 'Beauty', icon: 'bi-brush' },
  ];
}
