import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriesDrawerComponent } from './categories-drawer.component';

describe('CategoriesDrawerComponent', () => {
  let component: CategoriesDrawerComponent;
  let fixture: ComponentFixture<CategoriesDrawerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CategoriesDrawerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CategoriesDrawerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
