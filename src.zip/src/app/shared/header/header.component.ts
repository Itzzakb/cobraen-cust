import { CommonModule } from '@angular/common';
import { Component, HostListener, Input, OnChanges, Signal, SimpleChanges } from '@angular/core';
import { RouterLink, RouterModule } from '@angular/router';
import { SignalService } from '../../services/signal.service';

interface MenuItem {
  label: string;
  type: 'link' | 'accordion' | 'social';
  subItems?: subItems[];
  path?: string;
}

interface subItems {
  label: string;
  path: string;

}

@Component({
  selector: 'app-header',
  standalone: true,
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  imports: [CommonModule, RouterLink, RouterModule],
})
export class HeaderComponent implements OnChanges {
  constructor(private signalService: SignalService) {}
  @Input() path: string = ''
  isMenuOpen = false;
  openSections: Set<string> = new Set();
  isSearchBoxVisible = false;
  isScrolled = false;


    ngOnChanges(changes: SimpleChanges): void {
    console.log('Changes detected:', changes);
    if (changes['path']) {
      if (changes['path'].currentValue === 'women' || changes['path'].currentValue === 'men') {
        console.log("it is working")
      } else {
        this.isScrolled = true
      }
    }

  }

  menuItems: MenuItem[] = [
    {
      label: 'Home',
      type: 'link',
      path: '/home',
    },
    { label: 'Men', type: 'link', path: '/landing-men'},
    { label: 'Women', type: 'link', path: '/landing-women'},
    { label: 'Top Categories', type: 'link', path: '/top-categories'},
    { label: 'Best Sellers', type: 'link', path: '/best-seller' },
    { label: 'New Arrivals', type: 'link', path: '/new-arrivals' },
    { label: 'Sale', type: 'link', path: '/sale' },
    { label: 'Membership', type: 'link', path: '/membership' },
    { label: 'My Account', type: 'accordion', path: '', subItems: [
      { label: 'Profile', path: '/profile' },
      { label: 'Orders', path: '/orders' },
      { label: 'Membership', path: '/membership' },
    ] },
    { label: 'Help & Support', type: 'accordion', path: '', subItems: [
      { label: 'FAQs', path: '/faqs' },      
      { label: 'Contact Us', path: '/contact' },
    ] },

    { label: 'About Us', type: 'link', path: '/about' },

    { label: '', type: 'social', subItems: [
      { label: 'Facebook', path: 'https://www.facebook.com/' },
      { label: 'Twitter', path: 'https://www.twitter.com/' },
      { label: 'Instagram', path: 'https://www.instagram.com/' },
    ] },

    // { label: 'My Orders', type: 'link', section: 'account' },
    // { label: 'Return Information', type: 'link', section: 'account' },
    // { label: 'A Contact Preference', type: 'link', section: 'account' },

    // { label: 'Help', type: 'link', section: 'info' },
    // { label: 'Track Order', type: 'link', section: 'info' },
    // { label: 'Delivery & Returns', type: 'link', section: 'info' },
    // { label: 'Sitemap', type: 'link', section: 'info' },
  ];

  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  toggleSection(label: string) {
    this.openSections.has(label)
      ? this.openSections.delete(label)
      : this.openSections.add(label);
  }

  isSectionOpen(label: string): boolean {
    return this.openSections.has(label);
  }

  // getItemsBySection(section: string) {
  //   return this.menuItems.filter((item) => item.section === section);
  // }

  toggleSearchBox() {
    this.isSearchBoxVisible = !this.isSearchBoxVisible;
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.isScrolled = window.scrollY > 80;
  }

  onCartClick() {
    this.signalService.openCart(); // or toggleCart()
  }
  onWishlistClick() {
    this.signalService.openWishlist(); // or toggleCart()
  }
}
