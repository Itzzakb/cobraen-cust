import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WishlistDrawerComponent } from './wishlist-drawer.component';

describe('WishlistDrawerComponent', () => {
  let component: WishlistDrawerComponent;
  let fixture: ComponentFixture<WishlistDrawerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WishlistDrawerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WishlistDrawerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
