import { Component, computed, OnDestroy } from '@angular/core';
import { SignalService } from '../../services/signal.service';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cart-drawer',
  imports: [CommonModule, RouterLink],
  templateUrl: './cart-drawer.component.html',
  styleUrl: './cart-drawer.component.scss'
})
export class CartDrawerComponent implements OnDestroy{

  constructor(public signalService: SignalService) {}
  isCartOpen = false;

cartItems = [
  {
    title: 'Vote New Shirt',
    price: 1599,
    originalPrice: 1999,
    discount: 20,
    color: 'Black',
    size: 'XL',
    quantity: 1,
    image: '/images/shirt.svg'
  },
  {
    title: 'Vote New Shirt',
    price: 1599,
    originalPrice: 1999,
    discount: 20,
    color: 'Black',
    size: 'XL',
    quantity: 1,
    image: 'assets/images/shirt.svg'
  }
];

get totalPrice() {
  return this.cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

openCart() {
  this.isCartOpen = true;
}

closeCart() {
  this.isCartOpen = false;
}

incrementQty(item: any) {
  item.quantity++;
}

decrementQty(item: any) {
  if (item.quantity > 1) item.quantity--;
}

removeItem(item: any) {
  this.cartItems = this.cartItems.filter(i => i !== item);
}

sidebarClass = computed(() =>
    this.signalService.isCartOpen() ? 'cart-sidebar open' : 'cart-sidebar'
  );

  ngOnDestroy(): void {
      this.signalService.close();
  }

}
