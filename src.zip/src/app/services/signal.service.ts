// cart-signal.service.ts
import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SignalService {
  // This signal holds whether the cart is open or not
  isCartOpen = signal(false);

  toggleCart() {
    this.isCartOpen.set(!this.isCartOpen());
  }

  openCart() {
    this.isCartOpen.set(true);
  }

  closeCart() {
    this.isCartOpen.set(false);
  }


  // This signal holds whether the wishlist is open or not
  isWishlistOpen = signal(false);

  toggleWishlist() {
    this.isWishlistOpen.set(!this.isWishlistOpen());
  }

  openWishlist() {
    this.isWishlistOpen.set(true);
  }

  closeWishlist() {
    this.isWishlistOpen.set(false);
  }


  private _isOpen = signal(false);
  isOpen = this._isOpen.asReadonly();

  open = () => this._isOpen.set(true);
  close = () => this._isOpen.set(false);
  toggle = () => this._isOpen.update(value => !value);
}
