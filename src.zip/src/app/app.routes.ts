import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./auth/sign-up/sign-up.component').then((m) => m.SignupComponent),
  },
  {
    path: 'home',
    redirectTo: 'landing-men'
  },
  {
    path: 'sign-up',
    loadComponent: () =>
      import('./auth/sign-up/sign-up.component').then((m) => m.SignupComponent),
  },
  {
    path: 'login',
    loadComponent: () =>
      import('./auth/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'landing-men',
    loadComponent: () =>
      import('./pages/landing-page-men/landing-page-men.component').then(
        (m) => m.LandingPageMenComponent
      ),
  },
  {
    path: 'landing-women',
    loadComponent: () =>
      import('./pages/landing-page-women/landing-page-women.component').then(
        (m) => m.LandingPageWomenComponent
      ),
  },
  {
    path: 'new-arrivals',
    loadComponent: () =>
      import('./pages/new-arrivals/new-arrivals-page.component').then(
        (m) => m.NewArrivalsPageComponent
      ),
  },
  {
    path: 'product-details/:id',
    loadComponent: () =>
      import('./pages/product-details/product-details.component').then(
        (m) => m.ProductDetailsComponent
      ),
  },
  {
    path: 'memebership',
    loadComponent: () =>
      import('./pages/memebership/memebership.component').then(
        (m) => m.MemebershipComponent
      ),
  },
  {
    path: 'profile',
    loadComponent: () =>
      import('./pages/profile/profile.component').then(
        (m) => m.ProfileComponent
      ),
  },
  {
    path: 'my-orders',
    loadComponent: () =>
      import('./pages/my-orders/my-orders.component').then(
        (m) => m.MyOrdersComponent
      ),
  },
  {
    path: 'track-order/:id',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component').then(
        (m) => m.OrderTrackingComponent
      ),
  },
  {
    path: 'about',
    loadComponent: () =>
      import('./pages/about/about.component').then(
        (m) => m.AboutComponent
      ),
  },
  {
    path: 'faq',
    loadComponent: () =>
      import('./pages/faq/faq.component').then(
        (m) => m.FaqComponent
      ),
  },
  {
    path: 'contact',
    loadComponent: () =>
      import('./pages/contact-us/contact-us.component').then(
        (m) => m.ContactUsComponent
      ),
  },
  {
    path: 'checkout',
    loadComponent: () => import('./pages/checkout/checkout.component').then(m => m.CheckoutComponent)
  },
  {
    path: 'best-seller',
    loadComponent: () => import('./pages/best-seller/best-seller.component').then(m => m.BestSellerComponent)
  },
  {
    path: 'sale',
    loadComponent: () => import('./pages/sale/sale.component').then(m => m.SaleComponent)
  },
  {
    path: 'top-categories',
    loadComponent: () => import('./pages/top-categories/top-categories.component').then(m => m.TopCategoriesComponent)
  },
];
