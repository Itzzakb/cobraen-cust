import { Component } from '@angular/core';

@Component({
  selector: 'app-memebership',
  imports: [],
  templateUrl: './memebership.component.html',
  styleUrl: './memebership.component.scss'
})
export class MemebershipComponent {

}
