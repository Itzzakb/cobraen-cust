import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemebershipComponent } from './memebership.component';

describe('MemebershipComponent', () => {
  let component: MemebershipComponent;
  let fixture: ComponentFixture<MemebershipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MemebershipComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemebershipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
