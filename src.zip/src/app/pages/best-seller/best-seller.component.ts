import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../../shared/header/header.component';
import { FooterComponent } from '../../shared/footer/footer.component';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-best-seller',
  imports: [CommonModule, RouterLink, HeaderComponent, FooterComponent, NgbDropdownModule, FormsModule],
  templateUrl: './best-seller.component.html',
  styleUrl: './best-seller.component.scss'
})
export class BestSellerComponent {
  newArrivals = [
    {
      id: 1,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/t-shirt.svg',
      price: '1,999',
      discountPrice: '1,599',
      discount: 20,
    },
    {
      id: 2,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/shirt.svg',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
    {
      id: 3,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/pant.svg',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
    {
      id: 4,
      name: 'Lavender AOP Comfort Shirt',
      image: '/images/men-categories/jacket.svg',
      price: 499,
      discountPrice: 399,
      discount: 20,
    },
  ];

  goBack() {
    window.history.back();
  }

  tshirts = [
  { label: 'All', count: 80 },
  { label: 'Oversized', count: 45 },
  { label: 'Basic', count: 35 },
];

shirts = [
  { label: 'All', count: 300 },
  { label: 'Stripes', count: 45 },
  { label: 'Linen', count: 35 },
  { label: 'Printed', count: 100 },
  { label: 'Oversized', count: 30 },
  { label: 'Plain', count: 90 },
];

jeans = [
  { label: 'All', count: 80 },
  { label: 'Oversized', count: 45 },
  { label: 'Basic', count: 35 },
];

sizes = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'];

colors = [
  '#000000', '#FFFFFF', '#EB5757', '#2F80ED', '#9B51E0', '#27AE60',
  '#F2994A', '#C4C4C4', '#F52C2C', '#F2F44B'
];


minPrice: number = 500;
maxPrice: number = 2000;

priceRanges = [
  { label: '₹500 – ₹1000', checked: false },
  { label: '₹1000 – ₹1500', checked: false },
  { label: '₹1500 – ₹2000', checked: false },
  { label: '₹2000 and Up', checked: false }
];

applyPriceFilter() {
  console.log('Selected Price Range:', this.minPrice, this.maxPrice);
  console.log('Checked Ranges:', this.priceRanges.filter(p => p.checked));
}
}
