import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';
import { FooterComponent } from "../../shared/footer/footer.component";
import { HeaderComponent } from "../../shared/header/header.component";

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [CommonModule, NgbAccordionModule, FooterComponent, HeaderComponent],
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent {
  faqs = [
    {
      question: 'How do I place an order?',
      answer:
        'Browse products, add them to your cart, and proceed to checkout using a payment method of your choice.'
    },
    {
      question: 'Can I cancel or modify my order?',
      answer:
        'You can cancel or edit your order before it\'s shipped. Go to “My Orders” or contact support immediately.'
    },
    {
      question: 'How long does shipping take?',
      answer:
        'Standard delivery usually takes 3–7 business days based on your location and availability of the item.'
    },
    {
      question: 'Do you ship internationally?',
      answer: 'Currently, we only deliver within India. We are working on expanding internationally soon.'
    },
    {
      question: 'What is your return policy?',
      answer:
        'You can return most items within 7 days of delivery. The item must be unused and in its original packaging.'
    },
    {
      question: 'What payment methods do you accept?',
      answer:
        'We accept UPI, credit/debit cards, net banking, and Cash on Delivery (COD).'
    }
  ];
}
