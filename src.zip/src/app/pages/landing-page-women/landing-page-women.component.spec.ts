import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LandingPageWomenComponent } from './landing-page-women.component';

describe('LandingPageWomenComponent', () => {
  let component: LandingPageWomenComponent;
  let fixture: ComponentFixture<LandingPageWomenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LandingPageWomenComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LandingPageWomenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
