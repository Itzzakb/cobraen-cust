import { FormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from "../../shared/header/header.component";
import { FooterComponent } from "../../shared/footer/footer.component";

@Component({
  selector: 'app-my-orders',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, HeaderComponent, FooterComponent],
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.scss']
})
export class MyOrdersComponent {
  orders = [
    {
      id: 'ORD12345678',
      date: '2025-06-18',
      status: 'Shipped',
      total: 2498,
      items: [
        { name: 'Blue Denim Shirt', qty: 1, price: 799, image: 'https://via.placeholder.com/60' },
        { name: 'Black Joggers', qty: 2, price: 1199, image: 'https://via.placeholder.com/60' }
      ]
    },
    {
      id: 'ORD12345555',
      date: '2025-06-10',
      status: 'Delivered',
      total: 1099,
      items: [
        { name: 'White T-Shirt', qty: 1, price: 1099, image: 'https://via.placeholder.com/60' }
      ]
    }
  ];

  // Cancel modal states
  showCancelModal = false;
  cancelIndex: number | null = null;
  cancelReasons = ['Changed my mind', 'Ordered by mistake', 'Found cheaper elsewhere', 'Other'];
  selectedReason: string = '';
  customReason: string = '';

  openCancelModal(index: number) {
    this.cancelIndex = index;
    this.selectedReason = '';
    this.customReason = '';
    this.showCancelModal = true;
  }

  closeCancelModal() {
    this.showCancelModal = false;
  }

  confirmCancel() {
    const reason = this.selectedReason === 'Other' ? this.customReason : this.selectedReason;
    console.log('Cancelled Order:', this.orders[this.cancelIndex!].id, 'Reason:', reason);
    this.closeCancelModal();
  }
}
