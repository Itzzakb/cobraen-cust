import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from "../../shared/header/header.component";
import { FooterComponent } from "../../shared/footer/footer.component";

@Component({
  selector: 'app-order-tracking',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  templateUrl: './order-tracking.component.html',
  styleUrls: ['./order-tracking.component.scss']
})
export class OrderTrackingComponent {
  order = {
    id: 'ORD12345678',
    date: '2025-06-20',
    estimatedDelivery: '2025-06-25',
    status: 'Shipped', // Placed | Packed | Shipped | Out for Delivery | Delivered
    address: {
      name: 'John Kumar',
      street: '123 MG Road',
      city: 'Delhi',
      state: 'Delhi',
      pin: '110001',
      phone: '+91 9876543210'
    },
    items: [
      {
        name: 'Blue Denim Shirt',
        quantity: 1,
        price: 799,
        image: 'https://via.placeholder.com/80'
      },
      {
        name: 'Black Joggers',
        quantity: 2,
        price: 1199,
        image: 'https://via.placeholder.com/80'
      }
    ]
  };

  statusSteps = ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
}
