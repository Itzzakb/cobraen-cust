import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';

import {
  NgbNav,
  NgbNavItem,
  NgbNavModule,
  NgbNavOutlet,
} from '@ng-bootstrap/ng-bootstrap';
import { FooterComponent } from "../../shared/footer/footer.component";
import { HeaderComponent } from "../../shared/header/header.component";

@Component({
  selector: 'app-product-details',
  imports: [
    CommonModule,
    RouterLink,
    NgbNav,
    NgbNavItem,
    NgbNavModule,
    NgbNavOutlet,
    NgbPopoverModule,
    FooterComponent,
    HeaderComponent
],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.scss',
})
export class ProductDetailsComponent {
  active = 1;
  selectedColor = 'black';
  selectedSize = 'XL';
  quantity = 1;
  pincode = '';

  colors = ['black', 'white', 'gray'];
  sizes = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'];

  incrementQty() {
    this.quantity++;
  }

  decrementQty() {
    if (this.quantity > 1) this.quantity--;
  }

  checkDelivery() {
    alert('Checking delivery for: ' + this.pincode);
  }

  showSharePopup = false;
  copied = false;
  pageUrl = window.location.href;

  openSharePopup() {
    this.showSharePopup = true;
    this.copied = false;
  }

  closeSharePopup() {
    this.showSharePopup = false;
  }

  copyLink() {
    navigator.clipboard.writeText(this.pageUrl).then(() => {
      this.copied = true;
      setTimeout(() => (this.copied = false), 2000);
    });
  }
}
