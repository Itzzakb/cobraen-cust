import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from "../../shared/header/header.component";
import { FooterComponent } from '../../shared/footer/footer.component';

@Component({
  selector: 'app-checkout',
  imports: [CommonModule, FormsModule, HeaderComponent, FooterComponent],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.scss'
})
export class CheckoutComponent {

  cartItems = [
    {
      name: 'Gradient Graphic T-shirt',
      size: 'Large',
      color: 'White',
      price: 145,
      quantity: 1,
      image: '/images/men-categories/t-shirt.svg'
    },
    {
      name: 'Checkered Shirt',
      size: 'Medium',
      color: 'Red',
      price: 180,
      quantity: 1,
      image: '/images/men-categories/shirt.svg'
    },
    {
      name: 'Skinny Fit Jeans',
      size: 'Large',
      color: 'Blue',
      price: 240,
      quantity: 1,
      image: '/images/men-categories/jacket.svg'
    }
  ];

  deliveryMethod = 'free';
  paymentMethods = ['Cash On Delivery', 'UPI', 'Bank Transfer'];
  paymentMethod = 'Cash On Delivery';

  accountType = 'register';
  billingOption = 'new';

  login = {
    email: '',
    password: ''
  };

  billing = {
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    postCode: '',
    country: '',
    state: ''
  };

  increaseQty(item: any) {
    item.quantity++;
  }

  decreaseQty(item: any) {
    if (item.quantity > 1) item.quantity--;
  }
}
