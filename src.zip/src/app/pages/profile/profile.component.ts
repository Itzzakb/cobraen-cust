import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../shared/header/header.component';
import { FooterComponent } from '../../shared/footer/footer.component';

export interface Address {
  houseNo: string;
  street: string;
  landmark: string;
  city: string;
  state: string;
  pin: string;
}


@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule, HeaderComponent, FooterComponent],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent {
isEditMode = false;

  user = {
    name: 'Amit Kumar',
    email: 'amit@example.com',
    phone: '+91 9876543210',
    address: '123, MG Road, Delhi, India',
    joined: 'March 2023',
    profileImage: '/images/men-dummy.jpg'
  };

  addresses: Address[] = [
    {
      houseNo: '123',
      street: 'Main St',
      landmark: 'Near Park',
      city: 'Delhi',
      state: 'Delhi',
      pin: '110001'
    },
    {
      houseNo: '456',
      street: 'Second Ave',
      landmark: 'Opp Mall',
      city: 'Mumbai',
      state: 'Maharashtra',
      pin: '400001'
    }
  ];

  showAddressForm = false;
  editingAddressIndex: number | null = null;
  addressFormValue: Address = this.getEmptyAddress();

  getEmptyAddress(): Address {
    return {
      houseNo: '',
      street: '',
      landmark: '',
      city: '',
      state: '',
      pin: ''
    };
  }

  addNewAddress() {
    this.editingAddressIndex = null;
    this.addressFormValue = this.getEmptyAddress();
    this.showAddressForm = true;
  }

  editAddress(i: number) {
    this.editingAddressIndex = i;
    this.addressFormValue = { ...this.addresses[i] };
    this.showAddressForm = true;
  }

  saveAddress() {
    if (this.editingAddressIndex !== null) {
      this.addresses[this.editingAddressIndex] = { ...this.addressFormValue };
    } else if (Object.values(this.addressFormValue).some(v => v.trim())) {
      this.addresses.push({ ...this.addressFormValue });
    }
    this.closeAddressForm();
  }

  closeAddressForm() {
    this.showAddressForm = false;
    this.addressFormValue = this.getEmptyAddress();
    this.editingAddressIndex = null;
  }


  editedUser = { ...this.user };

  enableEdit() {
    this.editedUser = { ...this.user };
    this.isEditMode = true;
  }

  saveProfile() {
    this.user = { ...this.editedUser };
    this.isEditMode = false;
  }

  cancelEdit() {
    this.isEditMode = false;
  }

  onImageSelected(event: Event) {
    const file = (event.target as HTMLInputElement)?.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.editedUser.profileImage = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

}
