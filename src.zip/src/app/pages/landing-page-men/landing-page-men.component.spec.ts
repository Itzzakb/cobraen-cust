import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LandingPageMenComponent } from './landing-page-men.component';

describe('LandingPageMenComponent', () => {
  let component: LandingPageMenComponent;
  let fixture: ComponentFixture<LandingPageMenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LandingPageMenComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LandingPageMenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
