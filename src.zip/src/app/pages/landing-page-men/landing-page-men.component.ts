import { Component } from '@angular/core';
import { HeaderComponent } from '../../shared/header/header.component';
import { FooterComponent } from '../../shared/footer/footer.component';
import { BannerComponent } from '../../components/banner/banner.component';
import { TopCategoriesComponent } from '../../components/top-categories/top-categories.component';
import { NewArrivalsComponent } from '../../components/new-arrivals/new-arrivals.component';
import { FullOutfitComponent } from '../../components/full-outfit/full-outfit.component';
import { BestSellerComponent } from '../../components/best-seller/best-seller.component';
import { DealAdComponent } from '../../components/deal-ad/deal-ad.component';
import { BottomNavComponent } from '../../components/bottom-nav/bottom-nav.component';
import { OnePieceComponent } from '../../components/one-piece/one-piece.component';

@Component({
  selector: 'app-landing-page-men',
  imports: [HeaderComponent, FooterComponent, BannerComponent, TopCategoriesComponent, NewArrivalsComponent, FullOutfitComponent, BestSellerComponent, DealAdComponent, BottomNavComponent, OnePieceComponent],
  templateUrl: './landing-page-men.component.html',
  styleUrl: './landing-page-men.component.scss'
})
export class LandingPageMenComponent {

}
